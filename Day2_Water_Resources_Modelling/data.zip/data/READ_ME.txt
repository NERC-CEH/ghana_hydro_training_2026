These data files include monthly timeseries of catchment rainfall, mm, air temperature, degrees celsius, and reservoir storage, as a percentage of total capacity, for three reservoirs.

The reservoirs are:

------------------------------------------
Code    | Name     			| GRanD ID   | Capacity (MCM)  | Country       | Uses
2026    | Barrios de Luna   | 2675		 | 308			   | Spain         | Irrigation, Hydropower
J2R006  | Gamkapoort		| 4304		 | 43.8			   | South Africa  | Flood Control
C1R001  | Vaal				| 4184		 | 3199			   | South Africa  | Irrigation

The data was collated from several sources:
For reservoir 2026:CEDEX, 2024. C.H. DUERO. Available from: https://ceh.cedex.es/anuarioaforos/{DUERO_csv}.asp.
For reservoirs J2R006 & C1R001: Storage: National Hydrological Services - Surface Water (Data, Dams, Floods and Flows) https://www.dws.gov.za/Hydrology/Default.aspx.aspx
								Temperature (ERA5) & precipitation (CHIRPS): https://zenodo.org/records/14161235 (10.5281/zenodo.14161235) from basin GRDC_1160378 and 1159800 respectively
Capacity and use data was obtained from the GRanD database (Global Reservoir and Dam database)
		 